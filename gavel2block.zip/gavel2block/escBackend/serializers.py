from django.contrib.auth.models import *
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import *

class EngineerCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = EngineerCategory
        fields = ['id', 'full_name', 'abbreviation']
    
class ProcessCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcessCategory
        fields = ['id', 'full_name', 'abbreviation']
    
class StageCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = StageCategory
        fields = ['id', 'full_name', 'abbreviation']

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User  # 选定模型
        fields = ('pk', 'username', 'email', 'password')  # 选定字段
        extra_kwargs = {
            'password': {'write_only': True},
        }  # 不返回密码字段

    def create(self, validated_data):
        # 重写ModelSerializer的create()方法以保存User实例
        user = User(
            email=validated_data['email'],
            username=validated_data['username'],
            password=validated_data['password']
        )
        # 可使用user.set_password()对密码编码，而不使用原始字符作为密码
        user.save()  # 保存User的实例
        return user

class EngineerAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = EngineerAccount
        fields = ['user', 'alias', 'name', 'is_engineer',
         'is_reviewer', 'is_admin', 'title',
         'latest_process', 'latest_stage']

class ReviewerAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewerAccount
        fields = ['user', 'alias', 'name', 'is_engineer',
         'is_reviewer', 'is_admin', 'title']

class AdminAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminAccount
        fields = ['user', 'alias', 'name', 'is_engineer',
         'is_reviewer', 'is_admin']

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ['id', 'stage', 'writer', 'context',
         'grade', 'edited', 'submited']

class ProcessSerializer(serializers.ModelSerializer):
    class Meta:
        model = Process
        fields = ['id', 'kind', 'owner', 'reviewer','comment',
         'current_stage', 'stage0_tried_times', 'stage1_tried_times',
         'stage2_tried_times','stage3_tried_times', 'stage4_tried_times']

class ProcessReviewerSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcessReviewer
        fields = ['id', 'process', 'reviewer']

class ProcessCommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcessComment
        fields = ['id', 'process', 'comment']