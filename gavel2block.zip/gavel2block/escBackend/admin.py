from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(EngineerCategory)
admin.site.register(ProcessCategory)
admin.site.register(StageCategory)
admin.site.register(EngineerAccount)
admin.site.register(ReviewerAccount)
admin.site.register(AdminAccount)
admin.site.register(Comment)
admin.site.register(Process)
admin.site.register(ProcessReviewer)
admin.site.register(ProcessComment)

