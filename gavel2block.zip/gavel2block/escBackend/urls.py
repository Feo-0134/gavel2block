from django.urls import path, include
from rest_framework.routers import DefaultRouter
from escBackend import views
from rest_framework import renderers

router = DefaultRouter()
router.register(r'user', views.UserViewSet)
router.register(r'engineer_kind', views.EngineerCategoryViewSet)
router.register(r'process_kind', views.ProcessCategoryViewSet)
router.register(r'stage_kind', views.StageCategoryViewSet)
router.register(r'engineer', views.EngineerAccountViewSet)
router.register(r'reviewer', views.ReviewerAccountViewSet)
router.register(r'admin', views.AdminAccountViewSet)
router.register(r'comment', views.CommentViewSet)
router.register(r'process', views.ProcessViewSet)
router.register(r'process_review', views.ProcessReviewerViewSet)
router.register(r'process_comment', views.ProcessCommentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]