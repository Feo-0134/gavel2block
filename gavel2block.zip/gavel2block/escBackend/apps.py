from django.apps import AppConfig


class EscbackendConfig(AppConfig):
    name = 'escBackend'
