from django.test import TestCase
from rest_framework.test import APIRequestFactory

class UserTest(TestCase):
    # Using the standard RequestFactory API to create a form POST request
    def test_create_user(self):
        factory = APIRequestFactory()
        request = factory.post('/user/', {'username': 'LiL Jet','password': 'passwd', 'email': 't-liljet@microsoft.com'}, format='json')
        print(request)
        self.assertIs(1==1, True)