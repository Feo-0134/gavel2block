from .models import *
from django.contrib.auth.models import User
from .serializers import *
from rest_framework import viewsets
from django.shortcuts import get_object_or_404



templateProcessId = 1
# templateAdminId = 1
templateReviewerId = 1
# templateEngineerId = 1
templateCommentId = 1


class EngineerCategoryViewSet(viewsets.ModelViewSet):
    queryset = EngineerCategory.objects.all()
    serializer_class = EngineerCategorySerializer

class ProcessCategoryViewSet(viewsets.ModelViewSet):
    queryset = ProcessCategory.objects.all()
    serializer_class = ProcessCategorySerializer

class StageCategoryViewSet(viewsets.ModelViewSet):
    queryset = StageCategory.objects.all()
    serializer_class = StageCategorySerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class EngineerAccountViewSet(viewsets.ModelViewSet):
    queryset = EngineerAccount.objects.all()
    serializer_class = EngineerAccountSerializer

class ReviewerAccountViewSet(viewsets.ModelViewSet):
    queryset = ReviewerAccount.objects.all()
    serializer_class = ReviewerAccountSerializer


class AdminAccountViewSet(viewsets.ModelViewSet):
    queryset = AdminAccount.objects.all()
    serializer_class = AdminAccountSerializer

class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer

class ProcessViewSet(viewsets.ModelViewSet):
    queryset = Process.objects.all()
    serializer_class = ProcessSerializer
    def perform_create(self, serializer):
        serializer.save()
        pid = serializer.data['id']
        reviewerTemplate = {
            "process": pid,
            "reviewer": templateReviewerId
        }
        process_reviewer_serializer = ProcessReviewerSerializer(data = reviewerTemplate)
        process_reviewer_serializer.is_valid()
        process_reviewer_serializer.save()
        processCommentTemplate = {
            "process": pid,
            "comment": templateCommentId
        }
        process_comment_serializer = ProcessCommentSerializer(data = processCommentTemplate)
        process_comment_serializer.is_valid()
        process_comment_serializer.save()

class ProcessReviewerViewSet(viewsets.ModelViewSet):
    queryset = ProcessReviewer.objects.all()
    serializer_class = ProcessReviewerSerializer

class ProcessCommentViewSet(viewsets.ModelViewSet):
    queryset = ProcessComment.objects.all()
    serializer_class = ProcessCommentSerializer

