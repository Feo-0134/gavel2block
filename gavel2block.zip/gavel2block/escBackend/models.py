from django.db import models
from django.contrib.auth.models import User

class GeneralCategory(models.Model):
    full_name = models.CharField(max_length=20)
    abbreviation = models.CharField(max_length=7)

class EngineerCategory(GeneralCategory):
    def __str__(self):
        return self.full_name

class ProcessCategory(GeneralCategory):
    def __str__(self):
        return self.full_name

class StageCategory(GeneralCategory):
    def __str__(self):
        return self.full_name

class EngineerAccount(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    alias = models.CharField(max_length=10, primary_key=True)
    name = models.CharField(max_length=20)
    is_engineer = models.BooleanField(default=False)
    is_reviewer = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    title = models.ForeignKey(EngineerCategory, on_delete=models.CASCADE)
    latest_process = models.BigIntegerField(default=-1)
    latest_stage = models.ForeignKey(StageCategory, on_delete=models.CASCADE)
    def __str__(self):
        return self.alias + ': ' + self.name

class ReviewerAccount(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    alias = models.CharField(max_length=10, primary_key=True)
    name = models.CharField(max_length=20)
    is_engineer = models.BooleanField(default=False)
    is_reviewer = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    title = models.ForeignKey(EngineerCategory, on_delete=models.CASCADE)
    def __str__(self):
        return self.alias + ': ' + self.name

class AdminAccount(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    alias = models.CharField(max_length=10, primary_key=True)
    name = models.CharField(max_length=20)
    is_engineer = models.BooleanField(default=False)
    is_reviewer = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    def __str__(self):
        return self.alias + ': ' + self.name

class Comment(models.Model):
    stage = models.ForeignKey(StageCategory, on_delete=models.CASCADE)
    writer = models.ForeignKey(ReviewerAccount, on_delete=models.CASCADE)
    context = models.TextField()
    grade = models.BigIntegerField(default=-1)
    edited = models.BooleanField(default=False)
    submited = models.BooleanField(default=False)
    def __str__(self):
        return self.stage + ': ' + self.writer

class Process(models.Model):
    kind = models.ForeignKey(ProcessCategory, on_delete=models.CASCADE)
    owner = models.ForeignKey(EngineerAccount, on_delete=models.CASCADE)
    reviewer = models.ManyToManyField(
        ReviewerAccount,
        through = 'ProcessReviewer',
        through_fields = ('process', 'reviewer')
    )
    comment = models.ManyToManyField(
        Comment,
        through = 'ProcessComment',
        through_fields = ('process', 'comment')
    )
    current_stage = models.ForeignKey(StageCategory, on_delete=models.CASCADE)
    stage0_tried_times = models.BigIntegerField(default=-1)
    stage1_tried_times = models.BigIntegerField(default=-1)
    stage2_tried_times = models.BigIntegerField(default=-1)
    stage3_tried_times = models.BigIntegerField(default=-1)
    stage4_tried_times = models.BigIntegerField(default=-1)
    def __str__(self):
        return self.owner + ': ' + self.kind

class ProcessReviewer(models.Model):
    process = models.ForeignKey(Process, on_delete=models.CASCADE)
    reviewer = models.ForeignKey(ReviewerAccount, on_delete=models.CASCADE)
    def __str__(self):
        return self.process + ': ' + self.reviewer

class ProcessComment(models.Model):
    process = models.ForeignKey(Process, on_delete=models.CASCADE)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE)
    def __str__(self):
        return self.process + ': ' + self.comment
