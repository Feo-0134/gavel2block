# gavel2block
a tool to host a ballot and related works
